package com.ensah.core.services.impl;

import com.ensah.core.bo.JournalisationEvenements;
import com.ensah.core.dao.IJournalisationDao;
import com.ensah.core.services.JournalisationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JournalisationServiceImpl implements JournalisationService {

    @Autowired
    private IJournalisationDao journalisationDao;

    /*@Override
    public Optional<JournalisationEvenements> getEvenementsByUtilisateur(Long idUtilisateur) {
        return journalisationDao.findById(idUtilisateur);
    }*/

    @Autowired
    public JournalisationServiceImpl(IJournalisationDao journalisationDao) {
        this.journalisationDao = journalisationDao;
    }

    @Override
    public List<JournalisationEvenements> getUserActions(Long idUtilisateur) {
        return journalisationDao.findByUtilisateur_IdUtilisateur(idUtilisateur);
    }

    /*@Override
    public List<JournalisationEvenements> getEvenementsByUtilisateur(Long idUtilisateur) {
        return journalisationDao.findByCompte_Utilisateur_IdUtilisateur(idUtilisateur);
    }*/
}
