package com.ensah.core.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ensah.core.bo.Compte;

import java.util.List;
import java.util.Optional;

public interface ICompteDao extends JpaRepository<Compte, Long>, ICompteDaoCustom, GenericJpa<Compte, Long> {

}

