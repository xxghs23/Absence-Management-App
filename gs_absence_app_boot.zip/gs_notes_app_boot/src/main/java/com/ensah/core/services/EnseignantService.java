package com.ensah.core.services;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Etudiant;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EnseignantService {

    List<Enseignant> getEnseignantByCin(String cin);
}
