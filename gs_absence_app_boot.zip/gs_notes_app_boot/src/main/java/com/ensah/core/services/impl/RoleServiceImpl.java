package com.ensah.core.services.impl;

import com.ensah.core.bo.Role;
import com.ensah.core.dao.IRoleDao;
import com.ensah.core.services.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private IRoleDao roleDao;

    public Role getRoleById(Long id) {
        return roleDao.findById(id).orElse(null);
    }

}
