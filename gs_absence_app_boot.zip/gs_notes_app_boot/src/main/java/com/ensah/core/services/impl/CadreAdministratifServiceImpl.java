package com.ensah.core.services.impl;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.services.CadreAdministratifService;
import com.ensah.core.dao.ICadreAdministrateurDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CadreAdministratifServiceImpl implements CadreAdministratifService {

    @Autowired
    private ICadreAdministrateurDao cadreAdministrateurDao;

    @Override
    public List<CadreAdministrateur> getCadreAdministratifByCin(String cin) {
        return cadreAdministrateurDao.findByCin(cin);
    }
}
