package com.ensah.core.services;

import com.ensah.core.bo.CadreAdministrateur;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CadreAdministratifService {

    List<CadreAdministrateur> getCadreAdministratifByCin(String cin);
}
