package com.ensah.core.services;

import com.ensah.core.bo.Compte;
import com.ensah.core.bo.Role;
import org.springframework.stereotype.Service;

@Service
public interface RoleService {

    public Role getRoleById(Long idRole);

}
