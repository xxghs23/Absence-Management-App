package com.ensah.core.dao;

import com.ensah.core.bo.LoginHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ILoginHistoryDao extends JpaRepository<LoginHistory, Long> {
    // Add any additional methods if needed{
}
