package com.ensah.core.services.impl;

import com.ensah.core.bo.Etudiant;
import com.ensah.core.services.EtudiantService;
import com.ensah.core.dao.IEtudiantDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class EtudiantServiceImpl implements EtudiantService {
    private IEtudiantDao etudiantDao;

    @Autowired
    public EtudiantServiceImpl(IEtudiantDao etudiantDao) {
        this.etudiantDao = etudiantDao;
    }
    @Override
    public List<Etudiant> getEtudiantByCne(String cne) {

        return etudiantDao.findByCne(cne);
    }


}
