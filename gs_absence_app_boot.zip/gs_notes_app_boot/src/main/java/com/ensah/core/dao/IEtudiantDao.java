package com.ensah.core.dao;


import com.ensah.core.bo.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface IEtudiantDao extends JpaRepository<Etudiant,Long>{
    List<Etudiant> findByCne(String cne);

}
