package com.ensah.core.dao;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Enseignant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ICadreAdministrateurDao extends JpaRepository<CadreAdministrateur, Long> {
    List<CadreAdministrateur>  findByCin(String cin);
}

