package com.ensah.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsNoteApp {



	public static void main(String[] args) {
		SpringApplication.run(GsNoteApp.class, args);
	}

}
