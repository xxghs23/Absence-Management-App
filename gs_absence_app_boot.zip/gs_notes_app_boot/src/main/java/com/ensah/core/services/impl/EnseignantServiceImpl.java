package com.ensah.core.services.impl;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.dao.IEnseignantDao;
import com.ensah.core.dao.IEtudiantDao;
import com.ensah.core.services.EnseignantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnseignantServiceImpl implements EnseignantService {

    @Autowired
    private IEnseignantDao enseignantDAO;

    @Autowired
    public EnseignantServiceImpl(IEnseignantDao enseignantDAO) {
        this.enseignantDAO = enseignantDAO;
    }

    @Override
    public List<Enseignant> getEnseignantByCin(String cin) {
        return enseignantDAO.findByCin(cin);
    }
}

