package com.ensah.core.services;

import com.ensah.core.bo.Etudiant;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EtudiantService {

    List<Etudiant> getEtudiantByCne(String cne);
}
