package com.ensah.core.dao;

import com.ensah.core.bo.UserAction;
import com.ensah.core.bo.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.crypto.codec.Utf8;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserActionDao extends JpaRepository<UserAction, Long> {
    List<UserAction> findByUser(Utilisateur user);
}
