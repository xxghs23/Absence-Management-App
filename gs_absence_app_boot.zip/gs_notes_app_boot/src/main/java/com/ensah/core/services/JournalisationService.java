package com.ensah.core.services;

import com.ensah.core.bo.JournalisationEvenements;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface JournalisationService {

    //List<JournalisationEvenements> getEvenementsByUtilisateur(Long idUtilisateur);
    List<JournalisationEvenements> getUserActions(Long idUtilisateur);
}

    //Optional<JournalisationEvenements> getEvenementsByUtilisateur(Long idUtilisateur);

