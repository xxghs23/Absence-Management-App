package com.ensah.gs_notes_app_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsNotesAppBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
